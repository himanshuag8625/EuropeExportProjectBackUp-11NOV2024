﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EuropeTrackX.Migrations
{
    public partial class FileandHBLActivitylogHistorytable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "FileAcitivityLogHistory",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    FileLogId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    ActivityId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    StatusId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    Comment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    StartDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    EndDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FileAcitivityLogHistory", x => x.Id);
                    table.ForeignKey(
                        name: "FK_FileAcitivityLogHistory_ActivityMaster_ActivityId",
                        column: x => x.ActivityId,
                        principalTable: "ActivityMaster",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_FileAcitivityLogHistory_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_FileAcitivityLogHistory_FileActivityLog_FileLogId",
                        column: x => x.FileLogId,
                        principalTable: "FileActivityLog",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_FileAcitivityLogHistory_StatusMaster_StatusId",
                        column: x => x.StatusId,
                        principalTable: "StatusMaster",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "HBLActivitylogHistory",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    HBLogId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ActivityId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    StatusId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Comment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    StartDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    EndDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    HblLogId = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HBLActivitylogHistory", x => x.Id);
                    table.ForeignKey(
                        name: "FK_HBLActivitylogHistory_ActivityMaster_ActivityId",
                        column: x => x.ActivityId,
                        principalTable: "ActivityMaster",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_HBLActivitylogHistory_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_HBLActivitylogHistory_HBLActivityLog_HblLogId",
                        column: x => x.HblLogId,
                        principalTable: "HBLActivityLog",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_HBLActivitylogHistory_StatusMaster_StatusId",
                        column: x => x.StatusId,
                        principalTable: "StatusMaster",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_FileAcitivityLogHistory_ActivityId",
                table: "FileAcitivityLogHistory",
                column: "ActivityId");

            migrationBuilder.CreateIndex(
                name: "IX_FileAcitivityLogHistory_FileLogId",
                table: "FileAcitivityLogHistory",
                column: "FileLogId");

            migrationBuilder.CreateIndex(
                name: "IX_FileAcitivityLogHistory_StatusId",
                table: "FileAcitivityLogHistory",
                column: "StatusId");

            migrationBuilder.CreateIndex(
                name: "IX_FileAcitivityLogHistory_UserId",
                table: "FileAcitivityLogHistory",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_HBLActivitylogHistory_ActivityId",
                table: "HBLActivitylogHistory",
                column: "ActivityId");

            migrationBuilder.CreateIndex(
                name: "IX_HBLActivitylogHistory_HblLogId",
                table: "HBLActivitylogHistory",
                column: "HblLogId");

            migrationBuilder.CreateIndex(
                name: "IX_HBLActivitylogHistory_StatusId",
                table: "HBLActivitylogHistory",
                column: "StatusId");

            migrationBuilder.CreateIndex(
                name: "IX_HBLActivitylogHistory_UserId",
                table: "HBLActivitylogHistory",
                column: "UserId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "FileAcitivityLogHistory");

            migrationBuilder.DropTable(
                name: "HBLActivitylogHistory");
        }
    }
}
