﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EuropeTrackX.Migrations
{
    public partial class addcolumnBookingArrivedshippingIn : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ArrivedCBM",
                table: "AdhocHBLActivityLog",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "BookingCBM",
                table: "AdhocHBLActivityLog",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Shippingtype",
                table: "AdhocHBLActivityLog",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ArrivedCBM",
                table: "AdhocHBLActivityLog");

            migrationBuilder.DropColumn(
                name: "BookingCBM",
                table: "AdhocHBLActivityLog");

            migrationBuilder.DropColumn(
                name: "Shippingtype",
                table: "AdhocHBLActivityLog");
        }
    }
}
