﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EuropeTrackX.Migrations
{
    public partial class addfreigkey : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "FileId",
                table: "HBLMaster",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_HBLMaster_FileId",
                table: "HBLMaster",
                column: "FileId");

            migrationBuilder.AddForeignKey(
                name: "FK_HBLMaster_FileMaster_FileId",
                table: "HBLMaster",
                column: "FileId",
                principalTable: "FileMaster",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_HBLMaster_FileMaster_FileId",
                table: "HBLMaster");

            migrationBuilder.DropIndex(
                name: "IX_HBLMaster_FileId",
                table: "HBLMaster");

            migrationBuilder.DropColumn(
                name: "FileId",
                table: "HBLMaster");
        }
    }
}
