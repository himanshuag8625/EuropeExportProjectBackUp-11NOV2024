﻿using EuropeTrackX.DataModel;
using EuropeTrackX.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace EuropeTrackX.Controllers
{
	//Activity 
	public class ActivityMasterController : Controller
	{
		private readonly ApplicationDBContext _context;

		public ActivityMasterController(ApplicationDBContext context)
		{
			_context = context;
		}

        // GET: ActivityMaster
        [Authorize(Roles = "Supervisor,Manager")]
        public async Task<IActionResult> Index()
        {
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.NameOfActivity).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            return View(await _context.ActivityMaster.Where(x => x.IsDelete == false).OrderBy(x => x.NameOfActivity).ToListAsync());
		}


        // GET: ActivityMaster/Create
        [Authorize(Roles = "Supervisor,Manager")]
        public IActionResult Create()
		{
			return View(new ActivityMaster());
		}

		// POST: ActivityMaster/Create
		// To protect from overposting attacks, enable the specific properties you want to bind to, for 
		// more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
		[HttpPost]
		[ValidateAntiForgeryToken]
        [Authorize(Roles = "Supervisor,Manager")]
        public async Task<IActionResult> Create([Bind("Id,NameOfActivity,ActivityType,Source")] ActivityMaster activityMaster)
		{
			if (ModelState.IsValid)
			{				
				_context.Add(activityMaster);
				await _context.SaveChangesAsync();
				return RedirectToAction(nameof(Index));
			}
			return View(activityMaster);
		}

        // GET: ActivityMaster/Edit/5
        [Authorize(Roles = "Supervisor,Manager")]
        public async Task<IActionResult> Edit(string? id)
		{
			if (id == null)
			{
				return NotFound();
			}

			var activityMaster = await _context.ActivityMaster.FindAsync(id);
			if (activityMaster == null)
			{
				return NotFound();
			}
			return View(activityMaster);
		}

		// POST: ActivityMaster/Edit/5
		// To protect from overposting attacks, enable the specific properties you want to bind to, for 
		// more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
		[HttpPost]
		[ValidateAntiForgeryToken]
        [Authorize(Roles = "Supervisor,Manager")]
        public async Task<IActionResult> Edit(string id, [Bind("Id,NameOfActivity,ActivityType,Source")] ActivityMaster activityMaster)
		{
			if (id != activityMaster.Id)
			{
				return NotFound();
			}

			if (ModelState.IsValid)
			{
				try
				{
					_context.Update(activityMaster);
					await _context.SaveChangesAsync();
				}
				catch (DbUpdateConcurrencyException)
				{
					if (!ActivityMasterExists(activityMaster.Id))
					{
						return NotFound();
					}
					else
					{
						throw;
					}
				}
				return RedirectToAction(nameof(Index));
			}
			return View(activityMaster);
		}
        //Delete by Id
        // GET: ActivityMaster/Delete/5
        [Authorize(Roles = "Supervisor,Manager")]
        public async Task<IActionResult> Delete(string? id)
		{
			if (id == null)
			{
				return NotFound();
			}

			var activityMaster = await _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false)
                .FirstOrDefaultAsync(m => m.Id == id);
			if (activityMaster == null)
			{
				return NotFound();
			}

			return View(activityMaster);
		}

		//Delete Confirmed
		// POST: ActivityMaster/Delete/5
		[HttpPost, ActionName("Delete")]
		[ValidateAntiForgeryToken]
        [Authorize(Roles = "Supervisor,Manager")]
        public async Task<IActionResult> DeleteConfirmed(string id)
		{
			var activityMaster = await _context.ActivityMaster.FindAsync(id);
			_context.ActivityMaster.Remove(activityMaster);
			await _context.SaveChangesAsync();
			return RedirectToAction(nameof(Index));
		}

		//Check activity is exits
		private bool ActivityMasterExists(string id)
		{
			return _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).Any(e => e.Id == id);
		}
        //Insert activity 
        [Authorize(Roles = "Supervisor,Manager")]
        public JsonResult InsertActivity(ActivityMaster activityMaster)
		 {
			string Msg = "";
			if (ModelState.IsValid)
			{
				var Isexits = _context.ActivityMaster.Where(x =>  x.IsActive == true && x.IsDelete == false && x.NameOfActivity==activityMaster.NameOfActivity && x.ActivityType==activityMaster.ActivityType).FirstOrDefault();

				if (Isexits==null)
				{
					_context.Add(activityMaster);
					_context.SaveChanges();
					Msg="Activity Insert Successfully";
				}
				else
				{
					Msg="Activity already added";
				}
			}
			else
			{
				Msg="Name of Activity and ActivityType not empty";
			}
			return Json(Msg);
		}
	}
}
