﻿using ClosedXML.Excel;
using DocumentFormat.OpenXml.Spreadsheet;
using EuropeTrackX.DataModel;
using EuropeTrackX.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Drawing;
using System.Net;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Linq.Dynamic.Core;
using System.Reflection;


namespace EuropeTrackX.Controllers
{
    //Upload Excel file data
    public class UploadController : Controller
    {

        ApplicationDBContext _context;
        public UploadController(ApplicationDBContext context)
        {
            _context = context;
        }

        [Authorize(Roles = "Supervisor,Manager")]
        public IActionResult Index()
        {
            ViewData["CountryMaster"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CountryName).ToList();
            Console.WriteLine(_context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList().Count);
            return View(new UploadViewModel());
        }
        //Upload Data 
        [HttpPost]
        [Authorize(Roles = "Supervisor,Manager")]
        public async Task<IActionResult> Index(UploadViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Save the uploaded file to the server
                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", model.File.FileName);
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await model.File.CopyToAsync(stream);
                }
                UploadFile(filePath);
            }
            // Return a response to the client
            return RedirectToAction("Index", "Dashboard");
        }

        public static DataTable GetDataFromExcel1(string path)
        {
            DataTable dt = new DataTable();
            try
            {
                using (XLWorkbook workBook = new XLWorkbook(path))
                {
                    IXLWorksheet workSheet = workBook.Worksheet(1);
                    bool firstRow = true;

                    foreach (IXLRow row in workSheet.Rows())
                    {
                        // Use the first row to add columns to DataTable.
                        if (firstRow)
                        {
                            int j = 0;
                            foreach (IXLCell cell in row.Cells())
                            {
                                if (!string.IsNullOrEmpty(cell.Value.ToString()))
                                {
                                    // Check the data type of the cell to set the appropriate column type in DataTable.
                                    //if (cell.DataType == XLDataType.DateTime)
                                    //{
                                    //    dt.Columns.Add(cell.Value.ToString());
                                    //}
                                    //else
                                    {
                                        dt.Columns.Add(cell.Value.ToString());
                                    }
                                }
                                j++;
                            }
                            firstRow = false;
                        }
                        else
                        {
                            if (!row.IsEmpty())
                            {
                                try
                                {
                                    int i = 0;
                                    DataRow toInsert = dt.NewRow();
                                    foreach (IXLCell cell in row.Cells(1, dt.Columns.Count))
                                    {
                                        try
                                        {
                                            if (cell.DataType == XLDataType.Number)
                                            {
                                                toInsert[i] = Convert.ToDateTime(cell.Value);
                                            }
                                            else
                                            {
                                                toInsert[i] = cell.Value.ToString();
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            // Handle any potential exceptions here.
                                        }
                                        i++;
                                    }
                                    dt.Rows.Add(toInsert);
                                }
                                catch (Exception ex)
                                {
                                    // Handle any potential exceptions here.
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle any potential exceptions here.
            }
            return dt;
        }


        public static DataTable GetDataFromExcel(string path)
        {
            DataTable dt = new DataTable();
            try
            {
                using (XLWorkbook workBook = new XLWorkbook(path))
                {

                    IXLWorksheet workSheet = workBook.Worksheet(1);
                    bool firstRow = true;

                    foreach (IXLRow row in workSheet.Rows())
                    {
                        //Use the first row to add columns to DataTable.
                        if (firstRow)
                        {
                            int j = 0;
                            foreach (IXLCell cell in row.Cells())
                            {
                                if (!string.IsNullOrEmpty(cell.Value.ToString()))
                                {
                                    dt.Columns.Add(cell.Value.ToString());
                                }
                                j++;
                            }
                            firstRow = false;
                        }
                        else
                        {
                            if (!row.IsEmpty())
                            {
                                try
                                {
                                    int i = 0;
                                    DataRow toInsert = dt.NewRow();
                                    foreach (IXLCell cell in row.Cells(1, dt.Columns.Count))
                                    {
                                        try
                                        {
                                            if (cell.Value.ToString().Trim() == "")
                                            {
                                                toInsert[i] = "";
                                            }
                                            else
                                            {
                                                toInsert[i] = cell.Value.ToString();
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                        }
                                        i++;
                                    }
                                    dt.Rows.Add(toInsert);
                                }
                                catch (Exception ex)
                                {

                                }
                            }
                            //}
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return dt;
        }


        //Upload files
        public async void UploadFile(string filePath)
        {
            try
            {
                List<CountryMaster> country = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();

                DataTable dtInput = GetDataFromExcel(filePath);

                foreach (DataRow row in dtInput.Rows)
                {
                    string prv_file = "";
                    HBLMaster HBL_exists = _context.HBLMaster.Include(x => x.File).Where(x => x.HBLNumber == row["HBL Nr"].ToString() && x.Booking == row["Booking #"].ToString()).FirstOrDefault();
                    FileMaster File_exists = _context.FileMaster.Where(x => x.FileNumber == row["File Number"].ToString().Trim()).FirstOrDefault();
                    if (HBL_exists == null)
                    {
                        if (File_exists == null)
                        {
                            File_exists = new FileMaster();
                            File_exists.Country = country.Where(x => x.CountryName == row["Country Name"].ToString().Trim() && x.IsActive == true && x.IsDelete == false).FirstOrDefault();
                            File_exists.FileNumber = row["File Number"].ToString();
                            File_exists.EnterDate = DateTime.UtcNow;
                            File_exists.Etd = ConvertExcelSerialDateToDateTime(row["E.T.D"].ToString());

                            File_exists.DraftCutoff = ConvertExcelSerialDateToDateTime(row["Draft Cutoff"].ToString());

                            prv_file = row["File Number"].ToString();
                            _context.FileMaster.Add(File_exists);

                            string user = "";
                            if (row["User Name"].ToString() != "")
                            {
                                user = _context.Users.Where(x => x.EmpId.ToString() == row["User Name"].ToString().ToString() && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();

                                var fileallocation = new FileActivityLog
                                {
                                    FileId = File_exists.Id,
                                    UserId = user,
                                    ActivityId = _context.ActivityMaster.Where(x => x.NameOfActivity == "FileAllocation" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault(),     //"5f396d86-71af-4979-a176-2d3165d32501",
                                    StatusId = _context.StatusMaster.Where(x => x.Status == "WIP" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault(),//   "df84295f-5248-41ab-a743-73f9ffa6085a",										
                                    StartDate = DateTime.UtcNow,
                                    EndDate = DateTime.UtcNow,
                                };
                                _context.FileActivityLog.Add(fileallocation);
                            }
                            _context.SaveChanges();
                        }

                        HBLMaster hbl_number = _context.HBLMaster.Where(x => x.HBLNumber == row["HBL Nr"].ToString()).FirstOrDefault();
                        if (hbl_number == null)
                        {
                            var hblNumber = row["HBL Nr"].ToString();
                            var customerName = row["Customer Name"].ToString();
                            var container = row["Container"].ToString();
                            var booking = row["Booking #"].ToString();

                            // Create a new HBL object and set its properties
                            var hbl = new HBLMaster
                            {
                                HBLNumber = hblNumber,
                                FileId = File_exists.Id,
                                CustomerName = customerName,
                                Container = container,
                                Booking = booking,
                                EnterDate = DateTime.UtcNow
                            };
                            // Insert the HBL object into the database
                            _context.HBLMaster.Add(hbl);
                            _context.SaveChanges();
                        }
                    }
                    else
                    {
                        HBLMaster hbl_number = _context.HBLMaster.Include(x => x.File).Where(x => x.HBLNumber == row["HBL Nr"].ToString()).FirstOrDefault();

                        var hblNumber = row["HBL Nr"].ToString();
                        var customerName = row["Customer Name"].ToString();
                        var container = row["Container"].ToString();
                        var booking = row["Booking #"].ToString();

                        //File_exists = _context.FileMaster.Where(x => x.FileNumber != row["File Number"].ToString().Trim() && _context.HBLMaster.Any(x => x.HBLNumber == row["HBL Nr"].ToString() && x.Booking == row["Booking #"].ToString())).FirstOrDefault();
                        //if (File_exists.FileNumber != row["File Number"].ToString() && _context.HBLMaster.Any(x => x.HBLNumber == row["HBL Nr"].ToString() && x.Booking == row["Booking #"].ToString()))
                        //{
                        //    // If the file number changes but HBL and booking are the same, update the file number
                        //    File_exists.FileNumber = row["File Number"].ToString();
                        //    File_exists.Etd = ConvertExcelSerialDateToDateTime(row["E.T.D"].ToString());
                        //    _context.FileMaster.Update(File_exists);
                        //    _context.SaveChanges();
                        //}
                        // Update a existing HBL object and set its properties
                        if (hbl_number != null)
                        {
                            hbl_number.File.FileNumber = row["File Number"].ToString();
                            hbl_number.File.Etd = ConvertExcelSerialDateToDateTime(row["E.T.D"].ToString());
                            hbl_number.HBLNumber = hblNumber;
                            //hbl_number.FileId = File_exists.Id;
                            hbl_number.CustomerName = customerName;
                            hbl_number.Container = container;
                            hbl_number.Booking = booking;
                            hbl_number.EnterDate = DateTime.UtcNow;
                        }

                        // Insert the HBL object into the database
                        _context.HBLMaster.Update(hbl_number);
                        _context.FileMaster.Update(hbl_number.File);
                        _context.SaveChanges();
                    }
                    
                    //else if (File_exists.FileNumber != row["File Number"].ToString() && _context.HBLMaster.Any(x => x.HBLNumber == row["HBL Nr"].ToString() && x.Booking == row["Booking #"].ToString()))
                    //{
                    //    // If the file number changes but HBL and booking are the same, update the file number
                    //    File_exists.FileNumber = row["File Number"].ToString();
                    //    File_exists.Etd = ConvertExcelSerialDateToDateTime(row["E.T.D"].ToString());
                    //    _context.FileMaster.Update(File_exists);
                    //    _context.SaveChanges();
                    //}
                    //else
                    //{
                    //    File_exists.Country = country.Where(x => x.CountryName == row["Country Name"].ToString().Trim() && x.IsActive == true && x.IsDelete == false).FirstOrDefault();
                    //    File_exists.FileNumber = row["File Number"].ToString();
                    //    //File_exists.EnterDate = DateTime.UtcNow;
                    //    File_exists.Etd = ConvertExcelSerialDateToDateTime(row["E.T.D"].ToString());

                    //    File_exists.DraftCutoff = ConvertExcelSerialDateToDateTime(row["Draft Cutoff"].ToString());

                    //    File_exists.FileNumber = row["File Number"].ToString();
                    //    _context.FileMaster.Update(File_exists);

                    //    string user = "";
                    //    if (row["User Name"].ToString() != "")
                    //    {
                    //        user = _context.Users.Where(x => x.EmpId.ToString() == row["User Name"].ToString().ToString() && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();

                    //        var fileallocation = new FileActivityLog
                    //        {
                    //            FileId = File_exists.Id,
                    //            UserId = user,
                    //            ActivityId = _context.ActivityMaster.Where(x => x.NameOfActivity == "FileAllocation" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault(),     //"5f396d86-71af-4979-a176-2d3165d32501",
                    //            StatusId = _context.StatusMaster.Where(x => x.Status == "WIP" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault(),//   "df84295f-5248-41ab-a743-73f9ffa6085a",										
                    //            StartDate = DateTime.UtcNow,
                    //            EndDate = DateTime.UtcNow,
                    //        };
                    //        _context.FileActivityLog.Add(fileallocation);
                    //    }
                    //    _context.SaveChanges();
                    //}

                    //FileMaster fileMaster = _context.FileMaster.Where(x => x.FileNumber == row["File Number"].ToString()).FirstOrDefault();
                    
                    
                }
                
                #region obsolutecode
                //using (var stream = new FileStream(filePath, FileMode.Open))
                //{
                //    using (var workbook = new XLWorkbook(stream))
                //    {
                //        //Read excel sheets
                //        var worksheet = workbook.Worksheet(1);
                //        var rows = worksheet.RowsUsed();
                //        int skip = 1;
                //        foreach (var row in rows)
                //        {
                //            string prv_file = "";
                //            if (skip != 1 && row.Cell(2).GetString().Trim() != "")
                //            {
                //                FileMaster File_exists = _context.FileMaster.Where(x => x.FileNumber == row.Cell(2).GetString()).FirstOrDefault();
                //                if (File_exists == null)
                //                {
                //                    File_exists = new FileMaster();
                //                    File_exists.Country = country.Where(x => x.CountryName == row.Cell(1).GetString()).FirstOrDefault();
                //                    File_exists.FileNumber = row.Cell(2).GetString();
                //                    File_exists.EnterDate = DateTime.UtcNow;
                //                    if (row.Cell(7).Value.ToString().Trim() != "")
                //                    {
                //                        try
                //                        {
                //                            DateTime conv;
                //                            if (DateTime.TryParse(row.Cell(7).Value.ToString(), out conv))
                //                            {
                //                                File_exists.Etd = conv;
                //                            }
                //                            else
                //                            {
                //                                // Handle the case when parsing fails
                //                                // You can assign a default value to File_exists.Etd or display an error message
                //                            }
                //                            //double d = double.Parse(row.Cell(7).Value.ToString());


                //                            //DateTime conv = DateTime.FromOADate(d);
                //                            //File_exists.Etd = conv;

                //                        }
                //                        catch (InvalidCastException ex)
                //                        {


                //                        }
                //                        //File_exists.Etd = row.Cell(7).GetDateTime();
                //                    }


                //                    if (row.Cell(8).Value.ToString().Trim() != "")
                //                    {
                //                        try
                //                        {

                //                            DateTime conv;
                //                            if (DateTime.TryParse(row.Cell(8).Value.ToString(), out conv))
                //                            {
                //                                File_exists.DraftCutoff = conv;
                //                            }
                //                            else
                //                            {
                //                                // Handle the case when parsing fails
                //                                // You can assign a default value to File_exists.Etd or display an error message
                //                            }

                //                            //double d = double.Parse(row.Cell(8).Value.ToString());
                //                            //DateTime conv = DateTime.FromOADate(d);
                //                            //File_exists.DraftCutoff = conv;
                //                        }
                //                        catch (InvalidCastException ex) { }
                //                        //File_exists.DraftCutoff = row.Cell(8).GetDateTime();
                //                    }
                //                    prv_file = row.Cell(2).GetString();
                //                    _context.FileMaster.Add(File_exists);

                //                    string user = "";
                //                    if (row.Cell(11).GetString().ToString()!="")
                //                    {
                //                        user= _context.Users.Where(x => x.EmpId.ToString()==row.Cell(11).GetString().ToString()).Select(x => x.Id).FirstOrDefault();

                //                        var fileallocation = new FileActivityLog
                //                        {
                //                            FileId=File_exists.Id,
                //                            UserId=user,
                //                            ActivityId=_context.ActivityMaster.Where(x => x.NameOfActivity=="FileAllocation").Select(x => x.Id).FirstOrDefault(),     //"5f396d86-71af-4979-a176-2d3165d32501",
                //                            StatusId=_context.StatusMaster.Where(x => x.Status=="WIP").Select(x => x.Id).FirstOrDefault(),//   "df84295f-5248-41ab-a743-73f9ffa6085a",										
                //                            StartDate=DateTime.UtcNow,
                //                            EndDate=DateTime.UtcNow,
                //                        };
                //                        _context.FileActivityLog.Add(fileallocation);
                //                    }
                //                    _context.SaveChanges();

                //                }
                //                HBLMaster hbl_number = _context.HBLMaster.Where(x => x.HBLNumber == row.Cell(5).GetString()).FirstOrDefault();
                //                if (hbl_number == null)
                //                {
                //                    var hblNumber = row.Cell(5).GetString();
                //                    var customerName = row.Cell(4).GetString();
                //                    var container = row.Cell(6).GetString();
                //                    var booking = row.Cell(3).GetString();

                //                    // Create a new HBL object and set its properties
                //                    var hbl = new HBLMaster
                //                    {
                //                        HBLNumber = hblNumber,
                //                        FileId = File_exists.Id,
                //                        CustomerName = customerName,
                //                        Container = container,
                //                        Booking = booking,
                //                        EnterDate = DateTime.UtcNow
                //                    };
                //                    // Insert the HBL object into the database
                //                    _context.HBLMaster.Add(hbl);
                //                    _context.SaveChanges();
                //                }

                //            }
                //            skip = skip + 1;
                //        }
                //    }
                //}
                #endregion
            }
            catch (Exception ex)
            {

            }
        }

        public static DateTime? ConvertExcelSerialDateToDateTime(string excelSerialDate)
        {

            if (excelSerialDate != null && excelSerialDate != "")
            {
                int.TryParse(excelSerialDate, out int result);
                if (result != null && result != 0)
                {
                    // Excel serial date starts from January 1, 1900 (Windows) or January 1, 1904 (Mac).
                    // You might need to adjust this depending on the exact start date used in your system.
                    DateTime baseDate = new DateTime(1900, 1, 1);

                    // Excel serial date is the number of days since the base date.
                    DateTime resultDate = baseDate.AddDays(result - 1);
                    return resultDate;
                }
                else
                {
                    DateTime resultDate = Convert.ToDateTime(excelSerialDate);
                    return resultDate;
                }
            }
            else
            {
                return null;
            }
        }
    }
}
