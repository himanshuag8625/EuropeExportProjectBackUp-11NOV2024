﻿namespace EuropeTrackX.ViewModels
{
    public class ChangePasswrod
    {
    }
}
