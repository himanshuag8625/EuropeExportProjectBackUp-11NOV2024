﻿using System;
namespace EuropeTrackX.ViewModels
{
	public class FileDashModel
    {
        public string Id { get; set; } 
		public string CountryName { get; set; }
        public string FileNumber { get; set; }
        public DateTime? ETD { get; set; }
        public DateTime? DraftCutOff { get; set; }
        public int CountofHBL { get; set; }
        public string ActivityId { get; set; }
        public string? StatusId { get; set; }
        public string Comment { get; set; }
        public string? UserId { get; set; }

        public int ProcessedHBL { get; set; }
        public int PendingHBL { get; set; }
        public double Completion { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}

