﻿namespace EuropeTrackX.ViewModels
{
    public class UserRoleViewModel
    {
        public string RoleId { get; set; }
        public string UserId { get; set; }
    }
}
