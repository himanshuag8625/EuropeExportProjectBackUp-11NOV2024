﻿namespace EuropeTrackX.ViewModels
{
    public class AdhocFileActivityLogViewModel
    {

        public string AdhocCountry { get; set; }
        public string AdhocFileNumber { get; set; }

        public string Activity { get; set; }

        public string Status { get; set; }

        public string? Comment { get; set; }

        public string User { get; set; } 

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

    }
}
