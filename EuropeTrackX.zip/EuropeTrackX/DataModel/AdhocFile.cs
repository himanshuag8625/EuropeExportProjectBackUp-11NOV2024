﻿using System.ComponentModel.DataAnnotations.Schema;

namespace EuropeTrackX.DataModel
{
    public class AdhocFile
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        public string CountryId { get; set; }

        public string AdhocFileNumber { get; set; } = null!;

        public string AdhocContainer { get; set; } = null!;
        public DateTime? EnterDate { get; set; }
        public bool? IsActive { get; set; } = true;
        public bool IsDelete { get; set; } = false;

        [ForeignKey("CountryId")]
        public virtual CountryMaster Country { get; set; } = null!;

        public virtual ICollection<AdhocFileActivityLog> AdhocFileActivityLog { get; } = new List<AdhocFileActivityLog>();
    }
}
