﻿using System;
using System.Collections.Generic;

namespace EuropeTrackX.DataModel
{

    public partial class StatusMaster
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        public string Status { get; set; } = null!;

        public string Value { get; set; } = null!;

        public bool? IsActive { get; set; } = true;
        public bool IsDelete { get; set; } = false;
        public virtual ICollection<FileActivityLog> FileActivityLogs { get; } = new List<FileActivityLog>();

        public virtual ICollection<HBLActivityLog> HBLActivityLogs { get; } = new List<HBLActivityLog>();
    }
}